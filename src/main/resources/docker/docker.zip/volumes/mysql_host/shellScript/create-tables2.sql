create schema newBegin;
use newBegin;

---- drop ----
DROP TABLE IF EXISTS `userInfo`;

---- create ----
create table IF not exists `userInfo`
(
 `id`               INT(20) AUTO_INCREMENT,
 `name`             VARCHAR(20) NOT NULL,
 `age`              INT(20) NOT NULL,
 `sex`              VARCHAR(6) NOT NULL,
 `created_at`       Datetime DEFAULT NULL,
 `updated_at`       Datetime DEFAULT NULL,
    PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
