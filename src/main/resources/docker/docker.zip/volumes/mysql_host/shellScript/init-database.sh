#run the setup script to create the DB and the schema in the DB
mysql -u root -proot begin < "/home/create-tables2.sql"