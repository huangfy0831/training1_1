create database BEGIN2
GO

USE BEGIN2
GO

---- drop ----
DROP TABLE IF EXISTS userInfo
GO

---- create ----
create table userInfo
(
 id               INT NOT NULL PRIMARY KEY,
 name             VARCHAR(20) NOT NULL,
 age              INT NOT NULL,
 sex              VARCHAR(6) NOT NULL,
 created_at       Datetime DEFAULT NULL,
 updated_at       Datetime DEFAULT NULL
)
GO
